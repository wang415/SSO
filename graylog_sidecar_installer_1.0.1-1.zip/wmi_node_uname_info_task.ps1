<?xml version="1.0" encoding="UTF-16"?>
 
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
 
  <RegistrationInfo>
 
    <Date>2017-10-09T05:00:00</Date>
 
    <Description>open command prompt</Description>
 
    <URI>\wmi_node_uname_info.ps1</URI>
 
  </RegistrationInfo>
 
  <Triggers>
 
    <CalendarTrigger>
 
      <StartBoundary>2017-10-09T05:00:00</StartBoundary>
 
      <Enabled>true</Enabled>
 
      <ScheduleByDay>
 
        <DaysInterval>1</DaysInterval>
 
      </ScheduleByDay>
 
    </CalendarTrigger>
 
  </Triggers>
 
  <Principals>
 
    <Principal id="Author">
 
      <UserId>S-1-5-18</UserId>
 
      <RunLevel>LeastPrivilege</RunLevel>
 
    </Principal>
 
  </Principals>
 
  <Settings>
 
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
 
    <DisallowStartIfOnBatteries>true</DisallowStartIfOnBatteries>
 
    <StopIfGoingOnBatteries>true</StopIfGoingOnBatteries>
 
    <AllowHardTerminate>true</AllowHardTerminate>
 
    <StartWhenAvailable>false</StartWhenAvailable>
 
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
 
    <IdleSettings>
 
      <Duration>PT10M</Duration>
 
      <WaitTimeout>PT1H</WaitTimeout>
 
      <StopOnIdleEnd>true</StopOnIdleEnd>
 
      <RestartOnIdle>false</RestartOnIdle>
 
    </IdleSettings>
 
    <AllowStartOnDemand>true</AllowStartOnDemand>
 
    <Enabled>true</Enabled>
 
    <Hidden>false</Hidden>
 
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
 
    <WakeToRun>false</WakeToRun>
 
    <ExecutionTimeLimit>PT72H</ExecutionTimeLimit>
 
    <Priority>7</Priority>
 
  </Settings>
 
  <Actions Context="Author">
 
    <Exec>
 
      <Command>C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe</Command>
 
      <Arguments>-ExecutionPolicy ByPass -File "C:\Program Files\wmi_exporter\wmi_node_uname_info.ps1"</Arguments>
 
    </Exec>
 
  </Actions>
 
</Task>